import { Component, OnInit } from '@angular/core';

import { IProductDetails } from '../iproduct-details';
import { CapServiceService } from '../cap-service.service';
import { CapStoreService } from '../cap-store.service';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.css']
})
export class AllProductsComponent implements OnInit {

  constructor(private productDetailsService: CapServiceService,private capService: CapStoreService) { }

  Products: IProductDetails[];
  pro: IProductDetails;
  ngOnInit() {

    this.productDetailsService.getAllProducts().subscribe(
      data => {
      this.Products = data;
        //this.functionCategory();
      },
      error => console.log(error));

  }

  addToCart(data: any){
    console.log(data);
    this.pro=new IProductDetails(data.prodName,data.price,data.discount);
    this.capService.addToCart(this.pro);
  }

}
