import { Merchant } from './merchant';

describe('Merchant', () => {
  it('should create an instance', () => {
    expect(new Merchant()).toBeTruthy();
  });
});
